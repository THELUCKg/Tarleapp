# TarleApp Library

A sample Android library for JitPack publishing.

To use:
```gradle
implementation 'com.github.YOUR_USERNAME:Tarleapp:main-SNAPSHOT'
```