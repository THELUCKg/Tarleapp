
package com.tarleapp

import android.content.Context
import android.widget.Toast

object TarleChat {
    fun showWelcome(context: Context) {
        Toast.makeText(context, "Welcome to TarleApp Library!", Toast.LENGTH_SHORT).show()
    }
}
